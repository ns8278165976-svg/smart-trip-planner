import 'package:flutter/material.dart';

void main() => runApp(const SmartTripPlannerApp());

class AppColors {
  static const navy = Color(0xFF102A43);
  static const blue = Color(0xFF2F80ED);
  static const lightBlue = Color(0xFFEAF3FF);
  static const background = Color(0xFFF7F9FC);
  static const text = Color(0xFF1F2937);
  static const muted = Color(0xFF667085);
  static const green = Color(0xFF16A34A);
}

class SmartTripPlannerApp extends StatelessWidget {
  const SmartTripPlannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Trip Planner',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.blue),
        fontFamily: 'Arial',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class Destination {
  final String name;
  final String country;
  final String image;
  final String description;
  final double rating;
  final String budget;
  final List<String> attractions;
  final List<Review> reviews;

  const Destination({
    required this.name,
    required this.country,
    required this.image,
    required this.description,
    required this.rating,
    required this.budget,
    required this.attractions,
    required this.reviews,
  });
}

class Review {
  final String name;
  final String text;
  final double rating;
  const Review(this.name, this.text, this.rating);
}

const destinations = [
  Destination(
    name: 'Maldives',
    country: 'Indian Ocean',
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=1000',
    description: 'A tropical destination known for turquoise water, beaches and relaxing island experiences.',
    rating: 4.8,
    budget: '\$120–\$250/day',
    attractions: ['Baa Atoll', 'Male City', 'Hulhumale Beach', 'Banana Reef'],
    reviews: [
      Review('Sarah', 'Beautiful beaches and an easy trip to plan.', 5),
      Review('Daniel', 'The destination information was very useful.', 4.5),
    ],
  ),
  Destination(
    name: 'Sydney',
    country: 'Australia',
    image: 'https://images.unsplash.com/photo-1506973035872-a4f7b6a6c9e8?w=1000',
    description: 'A vibrant city combining beaches, landmarks, food, culture and entertainment.',
    rating: 4.7,
    budget: '\$100–\$220/day',
    attractions: ['Opera House', 'Bondi Beach', 'Harbour Bridge', 'The Rocks'],
    reviews: [
      Review('Emma', 'Great combination of city and beach activities.', 5),
      Review('Noah', 'The planner made it easier to organise activities.', 4),
    ],
  ),
  Destination(
    name: 'Paris',
    country: 'France',
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1000',
    description: 'A classic European destination featuring art, architecture, cuisine and historic attractions.',
    rating: 4.6,
    budget: '\$110–\$230/day',
    attractions: ['Eiffel Tower', 'Louvre Museum', 'Seine River', 'Montmartre'],
    reviews: [
      Review('Olivia', 'Excellent for a first-time visit.', 4.5),
      Review('James', 'Clear destination and booking flow.', 4),
    ],
  ),
];

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                  color: AppColors.lightBlue,
                  borderRadius: BorderRadius.circular(28),
                ),
                child: const Icon(Icons.flight_takeoff, size: 54, color: AppColors.blue),
              ),
              const SizedBox(height: 28),
              const Text('Smart Trip Planner',
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: AppColors.navy)),
              const SizedBox(height: 12),
              const Text(
                'Discover destinations, plan your activities and keep your trip details organised in one place.',
                style: TextStyle(fontSize: 17, height: 1.5, color: AppColors.muted),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen())),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.blue,
                    padding: const EdgeInsets.symmetric(vertical: 17),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('Explore Destinations', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen())),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 17),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('Continue as Guest'),
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Trip Planner', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.person_outline)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        children: [
          const Text('Plan your next adventure', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: AppColors.navy)),
          const SizedBox(height: 7),
          const Text('Find a destination and start building your trip.', style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 20),
          TextField(
            readOnly: true,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExploreScreen())),
            decoration: const InputDecoration(
              hintText: 'Search destinations...',
              prefixIcon: Icon(Icons.search),
              suffixIcon: Icon(Icons.tune),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Popular destinations', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExploreScreen())),
                child: const Text('View all'),
              ),
            ],
          ),
          ...destinations.map((d) => DestinationCard(destination: d)),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const CircleAvatar(backgroundColor: AppColors.lightBlue, child: Icon(Icons.calendar_month, color: AppColors.blue)),
              title: const Text('My Trip Planner', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Review activities and booking details'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TripPlannerScreen())),
            ),
          ),
        ],
      ),
    );
  }
}

class DestinationCard extends StatelessWidget {
  final Destination destination;
  const DestinationCard({super.key, required this.destination});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.only(bottom: 14),
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DestinationDetailsScreen(destination: destination))),
        child: Row(
          children: [
            SizedBox(
              width: 115,
              height: 120,
              child: Image.network(destination.image, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const ColoredBox(color: AppColors.lightBlue, child: Icon(Icons.image_not_supported))),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(13),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(destination.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  const SizedBox(height: 4),
                  Text(destination.country, style: const TextStyle(color: AppColors.muted)),
                  const SizedBox(height: 9),
                  Row(children: [
                    const Icon(Icons.star, size: 17, color: Colors.amber),
                    const SizedBox(width: 4),
                    Text('${destination.rating}'),
                    const Spacer(),
                    Text(destination.budget, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ]),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});
  @override State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final filtered = destinations.where((d) =>
      d.name.toLowerCase().contains(query.toLowerCase()) ||
      d.country.toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Explore Destination', style: TextStyle(fontWeight: FontWeight.bold))),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 14),
          child: TextField(
            autofocus: true,
            onChanged: (v) => setState(() => query = v),
            decoration: const InputDecoration(
              hintText: 'Search by destination or country',
              prefixIcon: Icon(Icons.search),
            ),
          ),
        ),
        Expanded(
          child: filtered.isEmpty
            ? const Center(child: Text('No destinations found'))
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: filtered.length,
                itemBuilder: (_, i) => DestinationCard(destination: filtered[i]),
              ),
        ),
      ]),
    );
  }
}

class DestinationDetailsScreen extends StatelessWidget {
  final Destination destination;
  const DestinationDetailsScreen({super.key, required this.destination});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 260,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            title: Text(destination.name),
            background: Image.network(destination.image, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const ColoredBox(color: AppColors.lightBlue)),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.star, color: Colors.amber),
                const SizedBox(width: 6),
                Text('${destination.rating} rating', style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                Chip(label: Text(destination.budget)),
              ]),
              const SizedBox(height: 16),
              const Text('About this destination', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(destination.description, style: const TextStyle(height: 1.5, color: AppColors.muted)),
              const SizedBox(height: 22),
              const Text('Attractions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              ...destination.attractions.map((a) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const CircleAvatar(backgroundColor: AppColors.lightBlue, child: Icon(Icons.place_outlined, color: AppColors.blue)),
                title: Text(a, style: const TextStyle(fontWeight: FontWeight.w600)),
              )),
              const SizedBox(height: 15),
              const Text('Reviews', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              ...destination.reviews.map((r) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      CircleAvatar(child: Text(r.name[0])),
                      const SizedBox(width: 10),
                      Text(r.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      const Icon(Icons.star, size: 16, color: Colors.amber),
                      Text('${r.rating}'),
                    ]),
                    const SizedBox(height: 9),
                    Text(r.text, style: const TextStyle(color: AppColors.muted)),
                  ]),
                ),
              )),
            ]),
          ),
        ),
      ]),
      bottomSheet: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 14),
          color: Colors.white,
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add to My Trip'),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TripPlannerScreen(destination: destination))),
            ),
          ),
        ),
      ),
    );
  }
}

class TripPlannerScreen extends StatefulWidget {
  final Destination? destination;
  const TripPlannerScreen({super.key, this.destination});
  @override State<TripPlannerScreen> createState() => _TripPlannerScreenState();
}

class _TripPlannerScreenState extends State<TripPlannerScreen> {
  final List<String> activities = [];
  @override
  void initState() {
    super.initState();
    if (widget.destination != null) activities.add('Explore ${widget.destination!.name}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Trip Planner', style: TextStyle(fontWeight: FontWeight.bold))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('My Trip', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                Text(widget.destination?.name ?? 'Your planned destinations', style: const TextStyle(color: AppColors.muted)),
              ]),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Planned activities', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (activities.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No activities added yet. Add a destination to begin planning.')))
          else
            ...activities.asMap().entries.map((e) => Card(
              child: ListTile(
                leading: CircleAvatar(child: Text('${e.key + 1}')),
                title: Text(e.value),
                subtitle: const Text('Planned activity'),
                trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => activities.removeAt(e.key))),
              ),
            )),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: activities.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingSummaryScreen(destination: widget.destination, activities: activities))),
            child: const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('Continue to Booking Summary')),
          ),
        ],
      ),
    );
  }
}

class BookingSummaryScreen extends StatelessWidget {
  final Destination? destination;
  final List<String> activities;
  const BookingSummaryScreen({super.key, required this.destination, required this.activities});

  @override
  Widget build(BuildContext context) {
    final name = destination?.name ?? 'Smart Trip';
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Summary', style: TextStyle(fontWeight: FontWeight.bold))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Review your trip', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: AppColors.navy)),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                const Divider(height: 28),
                const Text('Selected activities', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...activities.map((a) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Row(children: [const Icon(Icons.check_circle, size: 18, color: AppColors.green), const SizedBox(width: 8), Expanded(child: Text(a))]),
                )),
                const Divider(height: 28),
                const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Estimated budget'), Text('\$500', style: TextStyle(fontWeight: FontWeight.bold)),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ConfirmationScreen())),
            child: const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('Confirm Booking')),
          ),
        ],
      ),
    );
  }
}

class ConfirmationScreen extends StatelessWidget {
  const ConfirmationScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const CircleAvatar(radius: 42, backgroundColor: Color(0xFFE8F7EE), child: Icon(Icons.check, size: 48, color: AppColors.green)),
              const SizedBox(height: 22),
              const Text('Booking Confirmed', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              const Text('Your trip details have been saved in Smart Trip Planner.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, height: 1.5)),
              const SizedBox(height: 28),
              FilledButton(
                onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                child: const Padding(padding: EdgeInsets.symmetric(horizontal: 28, vertical: 14), child: Text('Back to Home')),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
