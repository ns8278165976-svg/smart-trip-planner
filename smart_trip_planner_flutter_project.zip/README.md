# Smart Trip Planner

ICT725 User Experience and Mobile Application Development – Assessment 4

A Flutter cross-platform frontend based on the Smart Trip Planner high-fidelity prototype from Assessment 3.

## Implemented major features
1. Destination Discovery
   - Explore destinations
   - Search destinations
   - Destination details
   - Attractions and reviews
2. Trip Planning and Booking
   - Add destination to trip
   - Trip planner
   - Booking summary
   - Booking confirmation

## Run
1. Install Flutter and Android Studio.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Start an Android emulator.
5. Run `flutter run`.

## Notes
This is a frontend prototype using local sample data. It does not claim to implement a real payment gateway, live travel API, or cloud database.
