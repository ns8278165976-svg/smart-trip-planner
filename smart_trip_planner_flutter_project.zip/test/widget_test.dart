import 'package:flutter_test/flutter_test.dart';
import 'package:smart_trip_planner/main.dart';

void main() {
  testWidgets('Smart Trip Planner opens welcome screen', (tester) async {
    await tester.pumpWidget(const SmartTripPlannerApp());
    expect(find.text('Smart Trip Planner'), findsOneWidget);
    expect(find.text('Explore Destinations'), findsOneWidget);
  });
}
